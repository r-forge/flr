#### Covariates ################################################################

#### Modified so temperature affects larval survival
rickerCovA <- function(){
  logl <- function(a, b, c, rec, ssb, covar){
              loglAR1(log(rec), log(a*(1+c*cvr)*ssb*exp(-b*ssb)))}

  initial <- structure(function(rec, ssb, covar) {
		# The function to provide initial values
    res  <-coefficients(lm(c(log(rec/ssb))~c(ssb)))
    return(FLPar(a=max(exp(res[1])), b=-max(res[2]), c=0.0))},

  # lower and upper limits for optim()
	lower=rep(-Inf, 3),
	upper=rep( Inf, 3))

	model  <- rec~a*(1+c*cvr)*ssb*exp(-b*ssb)

	return(list(logl=logl, model=model, initial=initial))}

#### Modified so temperature affects larval K
rickerCovB <- function(){
  logl <- function(a, b, c, rec, ssb, covar){
              loglAR1(log(rec), log(a*(1+c*covar)*ssb*exp(-b*ssb)))}

  initial <- structure(function(rec, ssb, covar) {
		# The function to provide initial values
    res  <-coefficients(lm(c(log(rec/ssb))~c(ssb)))
    return(FLPar(a=max(exp(res[1])), b=-max(res[2]), c=0.0))},

  # lower and upper limits for optim()
	lower=rep(-Inf, 3),
	upper=rep( Inf, 3))

	model  <- rec~a*ssb*exp(-b*(1+c*covar)*ssb)

	return(list(logl=logl, model=model, initial=initial))}

nao     <-read.table("http://www.cdc.noaa.gov/data/correlation/nao.data", skip=1, nrow=62, na.strings="-99.90")
dnms    <-list(quant="nao", year=1948:2009, unit="unique", season=1:12, area="unique")
nao     <-FLQuant(unlist(nao[,-1]), dimnames=dnms, units="nao")

#### include NAO as covar (note that it must be a FLQuants with a single component
#### called �covar� that matches the year span of the data) and adjust the model.

herSR         <-as.FLSR(her4)
model(herSR)  <-ricker()
herSR         <-fmle(herSR)

herCovA       <-as.FLSR(her4)
herCovA       <-transform(herCovA,ssb=ssb/1000,rec=rec/1000)
model(herCovA)<-rickerCovA()
covar(herCovA)<-FLQuants(covar=seasonMeans(trim(nao, year=dimnames(ssb(herCovA))$year)))
herCovA       <-fmle(herCovA,fixed=list(c=0))

summary(herCovA)

herCovB       <-as.FLSR(her4)
herCovB       <-transform(herCovB,ssb=ssb/1000,rec=rec/1000)
model(herCovB)<-rickerCovB()
covar(herCovB)<-FLQuants(seasonMeans(trim(nao, year=dimnames(ssb(herCovB))$year)))
herCovB       <-fmle(herCovB,fixed=list(c=0))

summary(herCovB)

AIC(her4RK)
AIC(herCovA)
AIC(herCovB)
################################################################################


#### AR1 #######################################################################
#### Modified so AR(1) residuals
rickerAR1 <- function()
  {
  ## log likelihood, assuming normal log.
  logl <- function(a, b, rho, rec, ssb)
      loglAR1(log(rec), log(a*ssb*exp(-b*ssb)), rho=rho)

  ## initial parameter values
  initial <- structure(function(rec, ssb) {
		# The function to provide initial values
    res  <-coefficients(lm(c(log(rec/ssb))~c(ssb)))
    return(FLPar(a=max(exp(res[1])), b=-max(res[2]), rho=0))
	},
  # lower and upper limits for optim()
	lower=rep(-Inf, 3),
	upper=rep(Inf, 3)
	)

  ## model to be fitted
	model  <- rec~a*ssb*exp(-b*ssb)

	return(list(logl=logl, model=model, initial=initial))}

model(her4SR)<-rickerAR1()
her4SR<-fmle(her4SR)
################################################################################

#### Jackhnife #################################################################
# get the covariance matrix for steepness and virgin biomass
model(nsher)<-ricker()
her4RK      <-fmle(nsher)
herCovar    <-as.matrix(vcov(her4RK)[c("a","b"),c("a","b"),1])

# calculate the lower trinagular decompostion
cholesky<-t(chol(herCovar))

cholesky

# generate a pair of random variates
c(params(her4RK)[1:2,1])+cholesky%*%as.vector(rnorm(2))

# set up 1000 random variates
params(her4RK)<-propagate(params(her4RK),1000)

for (i in 1:1000)
   params(her4RK)[c("a","b"),i]<-params(her4RK)[c("a","b"),1]+cholesky%*%as.vector(rnorm(2))

#check that these come from the original distribution
var(params(her4RK))
herCovar

#plot
plot(params(her4RK)[c("a","b"),])
plot(params(her4RK)["a"]~params(her4RK)["b"],ylab="a",xlab="b")
################################################################################

#### boot pairs #################################################################
her4RK     <-nsher
her4RK     <-fmle(nsher,model="ricker")

dmns      <-dimnames(ssb(her4RK))
dmns$iter <-1:100
mc.yrs    <-as.integer(sample(dmns$year,length(dmns$iter)*length(dmns$year),replace=T))

bootPair       <-her4RK
rec(bootPair)  <-FLQuant(c(rec(bootPair)[,ac(mc.yrs)]),dimnames=dmns)
ssb(bootPair)  <-FLQuant(c(ssb(bootPair)[,ac(mc.yrs)]),dimnames=dmns)

## fits across all iters independently
bootPair       <-fmle(bootPair)

points(params(bootPair  )["a",]~params(bootPair  )["b",],col="yellow",pch=19)
################################################################################

#### boot residuals ############################################################
dmns      <-dimnames(ssb(her4RK))
dmns$iter <-1:100
mc.yrs    <-as.integer(sample(dmns$year,length(dmns$iter)*length(dmns$year),replace=T))

bootRsdl       <-her4RK
rec(bootRsdl)  <-sweep(FLQuant(c(residuals(bootRsdl)[,ac(mc.yrs)]),dimnames=dmns),2,fitted(bootRsdl),"*")

## fits across all iters independently
bootRsdl       <-fmle(bootRsdl)

points(params(bootRsdl)["a",]~params(bootRsdl)["b",],col="yellow",pch=19)
################################################################################

################################################################################
# CI
ll<-logLik(her4RK)

# Chi-squared for 1 parameter
qchisq(.95,1)

## create a function to minimise
fn<- function(x, y) {(fmle(y,fixed=c(a=x))@logLik - (ll-qchisq(.95,1)/2))^2}

## lower bound
lwr<-optimise(f=fn,interval=c(params(her4RK)["a",1,drop=T]*.5,params(her4RK)["a",1,drop=T]),y=her4RK)

## upper bound
upr<-optimise(f=fn,interval=c(params(her4RK)["a",1,drop=T],params(her4RK)["a",1,drop=T]*2.0),y=her4RK)

param.grid  <-expand.grid(a=seq(lwr,upr,length.out=10),b=seq(lwr,upr,length.out=10),ll=NA)

## profile and plot liklihood around best guess
for (i in 1:length(param.grid[,1]))
   param.grid[i,"ll"]<-logLik(fmle(her4RK,fixed=(list(s=param.grid["a"],v=param.grid["b"]))))

image(  interp(param.grid[,"s"], param.grid[,"v"], param.grid[,"ll"]))
contour(interp(param.grid[,"s"], param.grid[,"v"], param.grid[,"ll"]),add=T)


image(  interp(param.grid[,"a"],param.grid[,"b"]*1000,param.grid[,"ll"]),xlab='a',ylab='b*1e+3')
contour(interp(param.grid[,"a"],param.grid[,"b"]*1000,param.grid[,"ll"]),add=T, levels=(logLik(her4RK)-qchisq(.95,2)/2), col="navy", lwd=2, add)
################################################################################


#### Ref pts ###################################################################
her4Brp <-FLBRP(her4,sr=her4RK)
her4Brp <-brp(her4Brp)
plot(her4Brp)


her4Boot <-FLBRP(her4,sr=bootPair)
plot(refpts(her4Boot)[c("fmax","msy"),c("harvest","yield","ssb")])

################################################################################

setMethod('loglAR1', signature(obs='FLQuant'),
   function(obs,hat=FLQuant(0.0,dimnames=dimnames(obs)),rho=0.0){

    # calculates likelihood for AR(1) process
    n   <- dim(obs)[2]
    rsdl<-(obs[,-1] - rho*obs[,-n] - hat[,-1] + rho*hat[,-n])
    s2  <- sum(rsdl^2, na.rm=T)
    s1  <-s2

    if (!all(is.na(rsdl[,1])))
      s1 <- s1+(1-rho^2)*(obs[,1]-hat[,1])^2

    #if (all(is.na(hat))) sigma2<-1e100 else

    sigma2   <- sigma(obs, hat)^2

    n        <- length(obs[!is.na(obs)])
    sigma2.a <- (1-rho^2)*sigma2
    res      <- (log(1/(2*pi))-n*log(sigma2.a)+log(1-rho^2)-s1/(2*sigma2.a))/2

    if (!is.finite(res))
      res <- -1e100

    return(res)}) # }}}


#### Deriso Schnute
dersch<-function(){
  logl <- function(a,b,c,rec,ssb) {
          res<-loglAR1(log(rec), log(a*ssb*(1-b*c*ssb)^(1/c)))
          print(log(a*ssb*(1-b*c*ssb)^(1/c)))
          print(log(rec))
          print(c(a,b,c,res))
          return(res)
          }

  ## initial parameter values
  initial <- structure(function(rec, ssb){
     slopeAt0 <- max(quantile(c(rec)/c(ssb), 0.9, na.rm = TRUE))
     maxRec   <- max(quantile(c(rec), 0.75, na.rm = TRUE))

     ## Bevholt by default c=-1
     return(FLPar(a=slopeAt0, b=1/maxRec, c=-1))},

  lower=rep(-Inf, 3),
	upper=rep( Inf, 3))

  model  <- rec~a*ssb*(1-b*c*ssb)^(1/c)

  return(list(logl = logl, model = model, initial = initial))}

model(nsher)<-dersch()
nsher<-fmle(nsher,fixed=list(c=-1))

