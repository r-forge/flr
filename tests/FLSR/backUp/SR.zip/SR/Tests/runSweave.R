library(FLCore)
library(numDeriv)
library(FLBRP)

load("C:\\My Dropbox\\FLRbook\\SR\\Data\\srr.RData")
#load("\\\\laurielpt\\Stuff\\FLR\\tests\\FLSR\\Data\\srr.RData")
#load("C:\\Stuff\\FLR\\tests\\FLSR\\Data\\srr.RData")

myDir="c:/My Dropbox/FLRbook/SR/"
#myDir="C:/Stuff/FLR/tests/FLSR/"

#### Functions #################################################################

#### to calculate gradient for parameter scaling
computeGrad=function(object,method="Richardson",
      method.args=list(eps=1e-4, d=0.0001, zero.tol=sqrt(.Machine$double.eps/7e-7), r=4, v=2, show.details=FALSE), ...){

     ## wrapper function from grad to call
     fn=function(x,sr){
       x.         =as.list(x)
       names(x.)  =dimnames(x)$params

       x.[["ssb"]]=sr@ssb
       x.[["rec"]]=sr@rec

       logl.      =sr@logl
       res        =do.call("logl.",x.)

       return(res)}
     
     grad(fn,x=c(object@initial(object@rec,object@ssb)),
               method=method,method.args=method.args,
               sr=object)}

#### Fit all SRRs
runCheckSRR=function(srr,srType){

    ps=srr
    gr=srr
    pr=srr
    nm=srr
    ad=srr

    #### Fit SRRs
    par(mfrow=c(6,9),mar=c(0,0,0,0),bg="grey")
    for (i in names(srr)){
        ssbRng=FLQuant(seq(0,max(ssb(srr[[i]]),na.rm=T),length.out=101))
        model(srr[[i]]) =do.call(srType,list())
        
        plot(rec(srr[[i]])~ssb(srr[[i]]),col="black",xlim=c(0,max(ssb(srr[[i]]))),ylim=c(0,max(rec(srr[[i]]))),pch=19,xaxt ="n",yaxt="n")
        mtext(i,side=3, line=-2)

        try  =try(srr[[i]]<-fmle(srr[[i]])) 
        if(!is(try,   'try-error')) lines(predict(srr[[i]],ssb=ssbRng)~ssbRng,col="blue")

        tryNM=try(nm[[i]]<-fmle(srr[[i]],method ="Nelder-Mead")) 
        if(!is(tryNM, 'try-error')) lines(predict(nm[[i]],ssb=ssbRng)~ssbRng,col="cyan")
        
        tryGr=try(gr[[i]]<-fmle(srr[[i]],control=list(parscale=1/pmax(0.000001,c(abs(computeGrad(srr[[i]])))))))
        if(!is(tryGr, 'try-error')) lines(predict(gr[[i]],ssb=ssbRng)~ssbRng,col="red")
        
        tryPr=try(pr[[i]]<-fmle(srr[[i]],control=list(parscale=parscale(srr[[i]]))))
        if(!is(tryPr, 'try-error')) lines(predict(pr[[i]],ssb=ssbRng)~ssbRng,col="green")
        
        model(srr[[i]]) =do.call(paste(srType,"SV",sep=""),list())
   
        spr0=mean(ssb(srr[[i]])/rec(srr[[i]]))*2
        #ps  =1/c(1,mean(ssb(srr[[i]]))*2)
        trySV=try(sv[[i]]<-fmle(srr[[i]],fixed=list(spr0=spr0))) #,control=list(parscale=ps)))         
        if(!is(trySV, 'try-error')) lines(predict(sv[[i]],ssb=ssbRng)~ssbRng,col="black")

        model(ad[[i]]) =srModel(srType)
        gr(ad[[i]])=function() NULL

        tryAD=try(ad[[i]]<-fmle(ad[[i]],method ="Nelder-Mead")) 
        if(!is(tryAD, 'try-error')) lines(predict(ad[[i]],ssb=ssbRng)~ssbRng,col="pink")
        }

    CF=data.frame(srr  =unlist(lapply(srr,logLik)),
                  nm   =unlist(lapply(nm, logLik)),
                  grad =unlist(lapply(gr, logLik)),
                  par  =unlist(lapply(pr, logLik)),
                  sv   =unlist(lapply(sv, logLik)),
                  ad   =unlist(lapply(sv, logLik)))

    print(CF)
    return(list(srr=srr,nm=nm,ad=ad,gr=gr,pr=pr,sv=sv))}

#### Check likelihood profiles
profileSRR=function(srr){
    par(mfrow=c(6,9),mar=c(0,0,0,0),bg="grey")
    for (i in names(srr)){
        profile(srr[[i]],which=c("a","b"),xaxt ="n",yaxt="n")
        mtext(i,side=3, line=-2)}}
################################################################################

srType<-"segreg"
    ps=srr
    gr=srr
    pr=srr  

    i<-"her-3a22"
    
      ssbRng=FLQuant(seq(0,max(ssb(srr[[i]]),na.rm=T),length.out=101))
#      if (srModelFlag)
         model(srr[[i]]) =do.call(srType,list())
#      else ## FLash::srModel
#         model(srr[[i]]) =srModel(srType)
#      gr(srr[[i]])=function() NULL

        plot(rec(srr[[i]])~ssb(srr[[i]]),col="black",xlim=c(0,max(ssb(srr[[i]]))),ylim=c(0,max(rec(srr[[i]]))),pch=19,xaxt ="n",yaxt="n")
        mtext(i,side=3, line=-2)

        try  =try(srr[[i]]<-fmle(srr[[i]])) 
        if(!is(try,   'try-error')) lines(predict(srr[[  i]],ssb=ssbRng)~ssbRng,col="blue")

        tryGr=try(gr[[i]]<-fmle(srr[[i]],control=list(parscale=1/pmax(0.000001,c(abs(computeGrad(srr[[i]])))))))
        if(!is(tryGr, 'try-error')) lines(predict(gr[[i]],ssb=ssbRng)~ssbRng,col="red")
        
        tryPr=try(pr[[i]]<-fmle(srr[[i]],control=list(parscale=parscale(srr[[i]]))))
        if(!is(tryPr, 'try-error')) lines(predict(pr[[i]],ssb=ssbRng)~ssbRng,col="green")
       
        sv=srr
        model(sv[[i]]) =do.call(paste(srType,"SV",sep=""),list())
   
        trySV=try(sv[[i]]<-fmle(srr[[i]],fixed=list(spr0=mean(ssb(srr[[i]])/rec(srr[[i]])*2))))
        if(!is(trySV, 'try-error')) lines(predict(sv[[i]],ssb=ssbRng)~ssbRng,col="green")
        
        ps=1/c(1,mean(ssb(srr[[i]]))*2,mean(ssb(srr[[i]])/rec(srr[[i]]))*2)[1:2]

        trySV=try(sv[[i]]<-fmle(srr[[i]],fixed=list(spr0=mean(ssb(srr[[i]])/rec(srr[[i]])*2)),control=list(parscale=1/ps)))
        if(!is(trySV, 'try-error')) lines(predict(sv[[i]],ssb=ssbRng)~ssbRng,col="black")

#### Beverton & Holt ###########################################################
bh=runCheckSRR(srr,srType="bevholt")
savePlot(paste(myDir,"Tests/Figs/bh.png",sep=""),type="png")
save(bh,file=paste(myDir,"Data/bh.RData",  sep=""))
bhLogLik<-array(unlist(lapply(bh, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
bhLogLik[c(18,25,28,30,41,48),]

profileSRR(bh[["srr"]])
savePlot(paste(myDir,"Tests/Figs/bhProfile.png",sep=""),type="png")

profileSRR(bh[["ps"]])
savePlot(paste(myDir,"Tests/Figs/bhProfilePS.png",sep=""),type="png")

### Ricker #####################################################################
rk=runCheckSRR(srr,srType="ricker")
savePlot(paste(myDir,"Tests/Figs/rk.png",sep=""),type="png")
save(rk,file=paste(myDir,"Data/rk.RData",  sep=""))
rkLogLik<-array(unlist(lapply(rk, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
rkLogLik[c(),]

rkLogLik<-array(unlist(lapply(rk, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
rkLogLik[c(18,25,28,30,41,48),]

profileSRR(rk[["srr"]])
savePlot(paste(myDir,"Tests/Figs/rkProfile.png",sep=""),type="png")

profileSRR(rk[["ps"]])
savePlot(paste(myDir,"Tests/Figs/rkProfilePS.png",sep=""),type="png")

### Cushing ####################################################################
ch=runCheckSRR(srr,srType="cushing")
savePlot(paste(myDir,"Tests/Figs/ch.png",sep=""),type="png")
save(ch,file=paste(myDir,"Data/ch.RData",  sep=""))
chLogLik<-array(unlist(lapply(ch, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
chLogLik[c(),]

chLogLik<-array(unlist(lapply(ch, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
chLogLik[c(18,25,28,30,41,48),]

profileSRR(ch[["srr"]])
savePlot(paste(myDir,"Tests/Figs/chProfile.png",sep=""),type="png")

profileSRR(ch[["ps"]])
savePlot(paste(myDir,"Tests/Figs/chProfilePS.png",sep=""),type="png")

profileSRR(ch[["as"]])
savePlot(paste(myDir,"Tests/Figs/chProfileAS.png",sep=""),type="png")

### Segmented Regression #######################################################
sg=runCheckSRR(srr,srType="segreg")

dirMY<-"\\\\laurielpt\\Stuff\\My Dropbox\\FLRbook\\SR\\"
savePlot(paste(myDir,"Tests/Figs/sg.png",sep=""),type="png")
save(sg,file=paste(myDir,"Data/sg.RData",  sep=""))

sgLogLik<-array(unlist(lapply(sg, function(x) lapply(x, logLik))),c(51,5),dimnames=list(stock=names(srr),method=names(sg)))
sgLogLik[c(),]

sgLogLik<-array(unlist(lapply(sg, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
sgLogLik[c(18,25,28,30,41,48),]

profileSRR(sg[["srr"]])
savePlot(paste(myDir,"Tests/Figs/sgProfile.png",sep=""),type="png")

profileSRR(sg[["gr"]])
savePlot(paste(myDir,"Tests/Figs/grProfilePS.png",sep=""),type="png")

profileSRR(sg[["pr"]])
savePlot(paste(myDir,"Tests/Figs/prProfilePS.png",sep=""),type="png")

profileSRR(sg[["sv"]])
savePlot(paste(myDir,"Tests/Figs/svProfilePS.png",sep=""),type="png")

### Shepherd ###################################################################
sh=runCheckSRR(srr,srType="shepherd")
savePlot(paste(myDir,"Tests/Figs/sh.png",sep=""),type="png")
save(sh,file=paste(myDir,"Data/sh.RData",  sep=""))
shLogLik<-array(unlist(lapply(sh, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
shLogLik[c(),]

shLogLik<-array(unlist(lapply(sh, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
shLogLik[c(18,25,28,30,41,48),]

profileSRR(sh[["srr"]])
savePlot(paste(myDir,"Tests/Figs/shProfile.png",sep=""),type="png")

profileSRR(sh[["ps"]])
savePlot(paste(myDir,"Tests/Figs/shProfilePS.png",sep=""),type="png")

profileSRR(sh[["as"]])
savePlot(paste(myDir,"Tests/Figs/shProfileAS.png",sep=""),type="png")

### Mean #######################################################################
mn=runCheckSRR(srr,srType="geomean")
savePlot(paste(myDir,"Tests/Figs/mn.png",sep=""),type="png")
save(mn,file=paste(myDir,"Data/mn.RData",  sep=""))
mnLogLik<-array(unlist(lapply(mn, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
mnLogLik[c(),]

mnLogLik<-array(unlist(lapply(mn, function(x) lapply(x, logLik))),c(51,3),dimnames=list(stock=names(srr),method=c("default","parscale","auto")))
mnLogLik[c(18,25,28,30,41,48),]

profileSRR(mn[["srr"]])
savePlot(paste(myDir,"Tests/Figs/mnProfile.png",sep=""),type="png")

profileSRR(mn[["ps"]])
savePlot(paste(myDir,"Tests/Figs/mnProfilePS.png",sep=""),type="png")

profileSRR(mn[["as"]])
savePlot(paste(myDir,"Tests/Figs/mnProfileAS.png",sep=""),type="png")

#### Profile to check Third Shape Parameter
if (srType=="shepherd"){
   par(mfrow=c(6,9),mar=c(0,0,0,0),bg="grey")
   for (i in names(srr)){
       profile(srr[[i]],which=c("c"),xaxt ="n",yaxt="n")
       mtext(i,side=3, line=-2)}
savePlot(paste(dir,"Figs/",srType,"ProfileC.png",sep=""),type="png")
################################################################################

################################################################################
#### srModel ###################################################################
################################################################################
model(srr[[i]])<-srModel("bevholt")
pars<-initial(srr[[i]])(rec(srr[[i]]),ssb(srr[[i]]))
logl(srr[[i]])(pars["a"],pars["b"],rec(srr[[i]]),ssb(srr[[i]]))
gr(srr[[i]])(pars["a"],pars["b"],rec(srr[[i]]),ssb(srr[[i]]))
gr(srr[[i]])=function() NULL
system.time(srr[[i]]<-fmle(srr[[i]]))
computeGrad(srr[[i]])
plot(srr[[i]])

model(srr[[i]])<-bevholt()
pars<-initial(srr[[i]])(rec(srr[[i]]),ssb(srr[[i]]))
logl(srr[[i]])(pars["a"],pars["b"],rec(srr[[i]]),ssb(srr[[i]]))
system.time(srr[[i]]<-fmle(srr[[i]]))
plot(srr[[i]])

################################################################################
