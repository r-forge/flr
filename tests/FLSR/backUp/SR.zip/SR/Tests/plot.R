SR<-ldply(bh[["nm"]],function(x) model.frame(FLQuants(ssb=ssb(x),rec=rec(x)))[,c("year","ssb","rec")])

hat<-function(x){
   ssbRng=FLQuant(seq(0,max(ssb(x),na.rm=T),length.out=101))
   model.frame(FLQuants(ssb=ssbRng,rec=predict(x,ssb=ssbRng)))[,c("ssb","rec")]}

fits<-cbind(method=rep(names(bh),each=101*51),ldply(bh, ldply, hat))


maxSR<-ddply(SR,.(.id),function(x) c(ssbMax=max(x$ssb),recMax=max(x$rec)))

fits    <-merge(fits,maxSR)
fits$ssb<-fits$ssb/fits$ssbMax
fits$rec<-fits$rec/fits$recMax
fits    <-fits[,c(".id","method","ssb","rec")]

SR    <-merge(SR,maxSR)
SR$ssb<-SR$ssb/SR$ssbMax
SR$rec<-SR$rec/SR$recMax
SR    <-SR[,c(".id","year","ssb","rec")]

ggplot(SR) + geom_point(aes(ssb,rec)) +
             geom_line( aes(ssb,rec,group=method,col=method),data=fits) +
             facet_wrap(~.id) + expand_limits(x = 0, y = 0) +
             scale_x_continuous(breaks=c(0,1)) + scale_y_continuous(breaks=c(0,1), limits=c(0,1))

 