library(FLash)

load("/home/lkell/Dropbox/FLRbook/chapters/SR/Data/srr.RData")

object<-srr[[1]]
model(object)<-bevholt()
object<-fmle(object)

predict(object)
recHat(object)

computeLL(object)

logl(object)(25507.7,6951.8,rec(object),ssb(object))

source("/home/lkell/Desktop/Stuff/FLR/pkg/FLash/R/srrFunc.R")
srrFunc.(object)
srrFunc.(object,"grad")

loglAR1(log(predict(object)/rec(object)))

srrFunc(SRNameCode("bevholt"), params(object), rec(object), ssb(object), what = "ll")

srrFunc.(object)

model(object)<-srModel("bevholt")
object<-fmle(object)

gr(object)(params(object)["a"],params(object)["b"],rec(object),ssb(object))

model(object)<-srModel("bevholt")

  gr(object)(25507.7,6951.8,rec(object),ssb(object))
logl(object)(25507.7,6951.8,rec(object),ssb(object))

r_<-rec(object)
r_[]<-1
1/exp(logl(object)(25507.7,6951.8,r_,ssb(object)))
