Hi

I am trying to finalise the documenation for FLSR and the new FLBioDym class but this has promoted some queries about the slots.

So I have some suggestions about the types of the slots, adding more validation and modifying iter() and propagate()

Slots in FLSR are  

       rec       "FLQuant"
       ssb       "FLQuant"
       covar     "FLQuant"
       logerror  "logical"    
       model     "formula"  
       logl      "function"  
       gr        "function"
       initial   "initial"  
       params    "FLPar"
       logLik    "logLik"   
       vcov      "array"
       hessian   "array" 
       details   "list"
       residuals "FLArarry"    
       fitted    "FLArray"   
       name      "character" 
       desc      "character"
       range     "numeric"

1) Why is logerror a logical? this means that we can only have normal & lognormal errors, what about gamma etc.?
2) Why are residuals and fitted of type FLArray rather than FLQuant?
3) Why are vcov & hessian not of type FLPar, this will make
        i) displaying slots with iters prettier and
        ii) it easier to perform calculations on them, e.g. derive SEs from params & FLQuants using the taylor expansion
4) There are also 10 slots that should be able to have iterations i.e.

       rec       "FLQuant"
       ssb       "FLQuant"
       covar     "FLQuant" 
       params    "FLPar"
       logLik    "logLik"   
       vcov      "array"
       hessian   "array" 
       details   "list"
       residuals "FLArarry"    
       fitted    "FLArray" 

Appropriate validation needs to be provided for these. For example if rec has n iters then so must all the other
apart friom SSB, But what if residuals has iterations?

5) Currently not all slots actually have iters and iter and propagate don´t work for all slots.

library(FLCore)
data(ple4)
pSR     =as.FLSR(ple4,model="bevholt")
pSR     =fmle(pSR)
covar(pSR)=FLQuants(covar=rec(pSR))
unlist(lapply(propagate(iter(pSR,1),2)[[c("rec","ssb","residuals","fitted")]], function(x) dims(x)$iter))

dims(covar(propagate(iter(pSR,1),2))[[1]])$iter
dims(params(propagate(iter(pSR,1),2)))$iter
dims(logLik(propagate(iter(pSR,1),2)))$iter
dims(details(propagate(iter(pSR,1),2)))$iter

dim( vcov(propagate(iter(pSR,1),2)))[3]
dim( hessian(propagate(iter(pSR,1),2)))[3]

6) Validation within slots e.g.
dimnames(rec(pSR))$age=4
validObject(pSR)
[1] TRUE

7) When FLSR fails the user has no easy way of knowing, so I suggest to add a slot that holds the fitting return message by iter

Laurie

