setGeneric("computeLogLik", function(object, ...) standardGeneric("computeLogLik"))

setMethod("computeLogLik", signature(object="FLSR"), function(object, par=params(object), ...){
	params(object)[dimnames(par)[[1]],] <- par
	par <- params(object)
	fpar <- names(as.list(object@logl))	
	fpar <- fpar[fpar!=""]
	lst <- list()
	length(lst) <- length(fpar)
	names(lst) <- fpar
	for(i in names(lst)[!(names(lst) %in% dimnames(params(object))[[1]])]) lst[[i]] <- slot(object, i)
	lst[names(lst) %in% dimnames(params(object))[[1]]] <- as.list(params(object))
	c(do.call(object@logl, lst))
})

