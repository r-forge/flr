library(odfWeave)
library(ggplot2)
library(FLCore)
library(FLBRP)
source("funs.R")

options(width = 80)
memory.limit(4000)

odfWeaveControl(zipCmd = c("C:/Program Files/WinRAR/rar A $$file$$ .", "C:/Program Files/WinRAR/rar X $$file$$"))
pkgVersions("matrix", ncol = 3)


### Scales figures ###########################################################
imageDef<-function(x,y,scale=200){
    ids           <-getImageDefs()

    ids$plotHeight=y*scale
    ids$dispHeight=y
    ids$plotWidth =x*scale
    ids$dispWidth =x

    setImageDefs(ids)}
    

#load("C:\\Stuff\\My Dropbox\\FLRbook\\Data\\RData\\her4.RData")
#load("C:\\Stuff\\My Dropbox\\FLRbook\\Data\\RData\\nsher.RData")
load("../../Data/RData/her4.RData")
load("../../Data/RData/nsher.RData")
#ata(nsher)
data(ple4)

ssbRng<-FLQuant(seq(0, max(ssb(nsher))*1.2, length.out=100))

srExmpl<-FLlst()
srExmpl[["bevholt"]] <-nsher
srExmpl[["ricker"]]  <-srExmpl[["bevholt"]]
srExmpl[["shepherd"]]<-srExmpl[["bevholt"]]
srExmpl[["cushing"]] <-srExmpl[["bevholt"]]
srExmpl[["segreg"]]  <-srExmpl[["bevholt"]]
srExmpl[["geomean"]] <-srExmpl[["bevholt"]]
srExmpl[["bevholt"]] <-srExmpl[["bevholt"]]

model(srExmpl[["bevholt"]] )<-bevholt()
model(srExmpl[["ricker"]]  )<-ricker()
model(srExmpl[["shepherd"]])<-shepherd()
model(srExmpl[["cushing"]] )<-cushing()
model(srExmpl[["segreg"]]  )<-segreg()
model(srExmpl[["geomean"]] )<-geomean()

srExmpl[["bevholt"]]  <-fmle(srExmpl[["bevholt"]])
srExmpl[["ricker"]]   <-fmle(srExmpl[["ricker"]])
srExmpl[["shepherd"]] <-fmle(srExmpl[["shepherd"]])
srExmpl[["cushing"]]  <-fmle(srExmpl[["cushing"]])
srExmpl[["segreg"]]   <-fmle(srExmpl[["segreg"]])
srExmpl[["geomean"]]  <-fmle(srExmpl[["geomean"]])
srExmpl[["bevholt"]]  <-fmle(srExmpl[["bevholt"]])

dfSR<-as.data.frame(rbind(cbind(rec=predict(srExmpl[["bevholt"]] ,ssb=ssbRng),ssb=ssbRng),
                          cbind(rec=predict(srExmpl[["ricker"]]  ,ssb=ssbRng),ssb=ssbRng),
                          cbind(rec=predict(srExmpl[["shepherd"]],ssb=ssbRng),ssb=ssbRng),
                          cbind(rec=predict(srExmpl[["cushing"]] ,ssb=ssbRng),ssb=ssbRng),
                          cbind(rec=predict(srExmpl[["segreg"]]  ,ssb=ssbRng),ssb=ssbRng),
                          cbind(rec=predict(srExmpl[["geomean"]] ,ssb=ssbRng),ssb=ssbRng)))

dfSR<-cbind(srr=rep(c("Beverton Holt","Ricker","Shepherd","Segmented Regression","Geometric Mean","Cushing"),each=dim(ssbRng)[2]),dfSR,ssbObs=NA,recObs=NA)

dfSR[1:dims(ssb(srExmpl[["bevholt"]]))$year,c("recObs","ssbObs")]<-model.frame(FLQuants(recObs=rec(srExmpl[["bevholt"]]), ssbObs=ssb(srExmpl[["bevholt"]])))[,c("recObs","ssbObs")]


#### Covariates ################################################################
#### Original Ricker
ricker <- function(){
  logl <- function(a, b, rec, ssb)
      loglAR1(log(rec), log(a*ssb*exp(-b*ssb)))

  initial <- structure(function(rec, ssb) {
		# The function to provide initial values
    res  <-coefficients(lm(c(log(rec/ssb))~c(ssb)))
    return(FLPar(a=max(exp(res[1])), b=-max(res[2])))},

  # lower and upper limits for optim()
	lower=rep(-Inf, 2),
	upper=rep( Inf, 2))

	model  <- rec~a*ssb*exp(-b*ssb)

	return(list(logl=logl, model=model, initial=initial))}

#### Modified so temperature affects larval survival
rickerCovA<-function (){
    logl <- function(a, b, c, rec, ssb, covar){
              a  <-a*(1+c*covar[[1]])
              obs<-log(rec)
              hat<-log(a*ssb*exp(-b*ssb))

              loglAR1(obs, hat, sigma(obs,hat)^2)}

    initial <- structure(function(rec, ssb, covar) {
        res <- coefficients(lm(c(log(rec/ssb)) ~ c(ssb)))
        return(FLPar(a = max(exp(res[1])),
                     b =-max(res[2]),
                     c =0.0))

    }, lower = c(rep(1e-10, 2), -1.0),
       upper = c(rep(Inf,   2),  1.0))


    model <- rec ~ a*(1+c*covar[[1]])*ssb*exp(-b*ssb)

    return(list(logl=logl,model=model,initial=initial))}
  
  #### Modified so temperature affects larval K
  rickerCovB<-function (){
      logl <- function(a, b, c, rec, ssb, covar){
                b  <-b*(1+c*covar[[1]])
                obs<-log(rec)
                hat<-log(a*ssb*exp(-b*ssb))
  
                loglAR1(obs, hat, sigma(obs,hat)^2)}
  
      initial <- structure(function(rec, ssb, covar) {
          res <- coefficients(lm(c(log(rec/ssb)) ~ c(ssb)))
          return(FLPar(a = max(exp(res[1])),
                      b =-max(res[2]),
                      c =0.0))
  
      }, lower = c(rep(1e-10, 2), -1.0),
         upper = c(rep(Inf,   2),  1.0))
  
      model <- rec ~ a*ssb*exp(-b*(1+c*covar[[1]])*ssb)
  
      return(list(logl = logl, model = model, initial = initial))}

nao     <-read.table("http://www.cdc.noaa.gov/data/correlation/nao.data", skip=1, nrow=62, na.strings="-99.90")
dnms    <-list(quant="nao", year=1948:2009, unit="unique", season=1:12, area="unique")
nao     <-FLQuant(unlist(nao[,-1]), dimnames=dnms, units="nao")

#### include NAO as covar (note that it must be a FLQuants with a single component
#### called ?covar? that matches the year span of the data) and adjust the model.

her4RK<-as.FLSR(her4)
model(her4RK)<-ricker()
her4RK<-fmle(her4RK)

herCovA<-as.FLSR(her4)
model(herCovA)<-rickerCovA()
covar(herCovA)<-FLQuants(covar=seasonMeans(trim(nao, year=dimnames(ssb(her4))$year)))
herCovA<-fmle(herCovA)

summary(herCovA)

herCovB<-as.FLSR(her4)
model(herCovB <-rickerCovB()
covar(herCovB)<-FLQuants(covar=seasonMeans(trim(nao, year=dimnames(ssb(her4RK))$year)))
herCovB <-fmle(herCovB)
summary(herCovB)

AIC(her4RK)
AIC(herCovA)
AIC(herCovB)
################################################################################


#### AR1 #######################################################################
#### Modified so AR(1) residuals
rickerAR1 <- function()
  {
  ## log likelihood, assuming normal log.
  logl <- function(a, b, rho, rec, ssb)
      loglAR1(log(rec), log(a*ssb*exp(-b*ssb)), rho=rho)

  ## initial parameter values
  initial <- structure(function(rec, ssb) {
		# The function to provide initial values
    res  <-coefficients(lm(c(log(rec/ssb))~c(ssb)))
    return(FLPar(a=max(exp(res[1])), b=-max(res[2]), rho=0))
	},
  # lower and upper limits for optim()
	lower=rep(-Inf, 3),
	upper=rep(Inf, 3)
	)

  ## model to be fitted
	model  <- rec~a*ssb*exp(-b*ssb)

	return(list(logl=logl, model=model, initial=initial))}

her4SR<-as.FLSR(her4)
model(her4SR)<-rickerAR1()
her4SR<-fmle(her4SR)
################################################################################

#### Jackhnife #################################################################
# get the covariance matrix for steepness and virgin biomass
model(nsher)<-ricker()
her4RK      <-fmle(nsher)
herCovar    <-as.matrix(vcov(her4RK)[c("a","b"),c("a","b"),1])

# calculate the lower trinagular decompostion
cholesky<-t(chol(herCovar))

cholesky

# generate a pair of random variates
c(params(her4RK)[1:2,1])+cholesky%*%as.vector(rnorm(2))

# set up 1000 random variates
params(her4RK)<-propagate(params(her4RK),1000)

for (i in 1:1000)
   params(her4RK)[c("a","b"),i]<-params(her4RK)[c("a","b"),1]+cholesky%*%as.vector(rnorm(2))

#check that these come from the original distribution
var(params(her4RK))
herCovar

#plot
plot(params(her4RK)[c("a","b"),])
plot(params(her4RK)["a"]~params(her4RK)["b"],ylab="a",xlab="b")
################################################################################

#### boot pairs #################################################################
her4RK     <-nsher
her4RK     <-fmle(nsher,model="ricker")

dmns      <-dimnames(ssb(her4RK))
dmns$iter <-1:100
mc.yrs    <-as.integer(sample(dmns$year,length(dmns$iter)*length(dmns$year),replace=T))

bootPair       <-her4RK
rec(bootPair)  <-FLQuant(c(rec(bootPair)[,ac(mc.yrs)]),dimnames=dmns)
ssb(bootPair)  <-FLQuant(c(ssb(bootPair)[,ac(mc.yrs)]),dimnames=dmns)

## fits across all iters independently
bootPair       <-fmle(bootPair)

points(params(bootPair  )["a",]~params(bootPair  )["b",],col="yellow",pch=19)
################################################################################

#### boot residuals ############################################################
dmns      <-dimnames(ssb(her4RK))
dmns$iter <-1:100
mc.yrs    <-as.integer(sample(dmns$year,length(dmns$iter)*length(dmns$year),replace=T))

bootRsdl       <-her4RK
rec(bootRsdl)  <-sweep(FLQuant(c(residuals(bootRsdl)[,ac(mc.yrs)]),dimnames=dmns),2,fitted(bootRsdl),"*")

## fits across all iters independently
bootRsdl       <-fmle(bootRsdl)

points(params(bootRsdl)["a",]~params(bootRsdl)["b",],col="yellow",pch=19)
################################################################################

################################################################################
# CI
ll<-logLik(her4RK)

# Chi-squared for 1 parameter
qchisq(.95,1)

## create a function to minimise
fn<- function(x, y) {(fmle(y,fixed=c(a=x))@logLik - (ll-qchisq(.95,1)/2))^2}

## lower bound for a
lwr<-optimise(f=fn,interval=c(params(her4RK)["a",1,drop=T]*.5,params(her4RK)["a",1,drop=T]),y=her4RK)

## upper bound for a
upr<-optimise(f=fn,interval=c(params(her4RK)["a",1,drop=T],params(her4RK)["a",1,drop=T]*2.0),y=her4RK)

## a seq
a=seq(lwr$minimum,upr$minimum,length.out=10)

## lower bound for b
lwr<-optimise(f=fn,interval=c(params(her4RK)["b",1,drop=T]*.5,params(her4RK)["b",1,drop=T]),y=her4RK)

## upper bound for b
upr<-optimise(f=fn,interval=c(params(her4RK)["b",1,drop=T],params(her4RK)["b",1,drop=T]*2.0),y=her4RK)

## b seq
b=seq(lwr$minimum,upr$minimum,length.out=10)

ll.mat <- matrix(NA, nrow=length(a), ncol=length(b))
a.mat <- matrix(a, nrow=length(a), ncol=length(b))
b.mat <- matrix(b, nrow=length(a), ncol=length(b), byrow=TRUE)

## profile and plot liklihood around best guess
for (i in 1:c(length(a)*length(b))) ll.mat[i] <- computeLogLik(her4RK,FLPar(a=a.mat[i],b=b.mat[i]))

#image(  interp(param.grid[,"s"], param.grid[,"v"], param.grid[,"ll"]))
#contour(interp(param.grid[,"s"], param.grid[,"v"], param.grid[,"ll"]),add=T)

image(a, b*1000, ll.mat,xlab='a',ylab='b*1e+3')
contour(a, b*1000,ll.mat, add=T, lwd=2, col="navy")

################################################################################


#### Ref pts ###################################################################
her4Brp <-FLBRP(her4,sr=her4RK)
her4Brp <-brp(her4Brp)
plot(her4Brp)


her4Boot <- computeRefpts(FLBRP(her4,sr=bootPair))

plot(refpts(her4Boot)[c("fmax","msy"),c("harvest","yield","ssb")])

################################################################################
#iFile    ="C:/Stuff/My Dropbox/FLRbook/SR/FLSR-Sweave.odt"
#oFile    ="C:/Stuff/My Dropbox/FLRbook/SR/FLSR.odt"
iFile    ="/home/ernesto/Dropbox/FLRbook/SR/FLSR-Sweave.odt"
oFile    ="/home/ernesto/Dropbox/FLRbook/SR/FLSR.odt"
odfWeave(iFile,oFile)

