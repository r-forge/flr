bioabsregplot.c         package:domfclstuff         R Documentation

_p_l_o_t _b_i_o_m_a_s_s _b_y _r_e_g_i_o_n

_D_e_s_c_r_i_p_t_i_o_n:

     Stack plot of biomass by region for all or a selection of regions.

_U_s_a_g_e:

     bioabsregplot.c(plotrepfile = "plot.rep", path, ylab = "Biomass",
          regions = seq(getnreg(plotrepfile)), title = plotrepfile,
           ncolor, noF = F, byyear=T, scale = 1, ...)

_A_r_g_u_m_e_n_t_s:

plotrepfile: - the _plot.rep_ file

    path: - path to the _plot.rep_ file if not included in
          'plotrepfile'

    ylab: - y-axis label

 regions: - selection of regions. Default is all of them. 

   title: - plot title

  ncolor: no. colors in rainbow color palette 

     noF: - if TRUE, plot nofishing biomass 

  byyear: - if FALSE, abundances retrieved for every time step, if
          TRUE, abundances retrieved for first step of each year

   scale: - allows re-scaling y-axis.  Defaults to 1 (no re-scaling) 

     ...: - other graphics parameters 

_A_u_t_h_o_r(_s):

     Pierre Kleiber

