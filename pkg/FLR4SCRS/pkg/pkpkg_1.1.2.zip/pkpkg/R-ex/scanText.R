### Name: scanText
### Title: read data from a vector of character strings
### Aliases: scanText


### ** Examples

scanText("A few short words")
as.numeric(scanText("1 2 3\n89 90"))
scanText("A B C \n 4 5 6", what = list("A", "A", "A", 0, 0, 0))



