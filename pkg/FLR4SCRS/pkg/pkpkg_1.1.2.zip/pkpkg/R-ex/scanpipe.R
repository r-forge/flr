### Name: scanpipe
### Title: read data through a pipe
### Aliases: scanpipe read.selection


### ** Examples

 x <- scanpipe("awk 'NF>=6{print $6}' myfile.dat",skip=1)



