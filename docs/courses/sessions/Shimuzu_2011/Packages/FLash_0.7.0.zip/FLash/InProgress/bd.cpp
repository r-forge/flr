#include <math.h>
#include "bd.hpp"

#ifdef WIN32
   #define SEXPDLLExport __declspec(dllexport) SEXP __cdecl
#else
   #define SEXPDLLExport SEXP
#endif

adouble db(FLRConstBD model, adouble bio, adouble *para)
   {
   adouble sp=0.0;

   switch(model){
      case FLRConst_DBFox:
         sp=para[0]*bio*(1.0-log(bio)/log(para[1]));
		     break;

      case FLRConst_DBSchaefer:
         sp=para[0]*bio*(1.0-bio/para[1]);
		     break;

      case FLRConst_DBPellaT:
         sp=bio*para[0]-pow(bio,para[2]*para[0]/para[1]);
		     break;

      case FLRConst_DBShepherd:
         sp=para[0]*bio/(1.0+bio/para[1])-para[2]*bio   ;
		     break;

      case FLRConst_DBGulland:
         sp=para[0]*bio*(para[1]-bio);
		     break;

      case FLRConst_DBFletcher:
         adouble lambda=pow(para[2],(para[2]/(para[2]-1)))/(para[2]-1.0);
         sp=lambda*para[1]*(bio/para[0])-lambda*para[1]*pow(bio/para[0],para[2]);
         break;}

   return sp;}

FLQuant_adolc dbFwd(FLQuant_adolc &biomass,FLQuant target,bool targetCatch,FLRConstBD model, adouble &params){

   for (int iYr=target.minyr(); iYr<=target.maxyr()-1; iYr++){
      if (targetCatch)
         biomass(1,iYr)=biomass(1,iYr) + sp(model,biomass(1,iYr),params) - target(1,iYr)*harvest(1,iYr);
      else
         biomass(1,iYr)=biomass(1,iYr) + sp(model,biomass(1,iYr),params) - target(1,iYr)                ;

   return(biomass);}
