#ifndef _INC_bd
#define _INC_bd

#include "flc_adolc.hpp"
#include "flc.hpp"
#include "ll.hpp"

typedef enum tagFLRConstBD
	{
   FLRConst_DBFox              =1,
   FLRConst_DBSchaefer         =2,
   FLRConst_DBPellaT           =3,
   FLRConst_DBShepherd         =4,
   FLRConst_DBGulland          =5,
   FLRConst_DBFletcher         =6
   } FLRConstBD;

adouble db(FLRConstBD model, adouble bio, adouble *para);

#endif /* _INC_bd */



